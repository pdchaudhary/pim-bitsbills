<?php

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\DataHubBundle\GraphQL\DataObjectType;

use GraphQL\Type\Definition\InputObjectType;
use GraphQL\Type\Definition\ListOfType;
use Pimcore\Tool;

/**
 * @internal
 */
final class LocalizedType extends InputObjectType
{
    /**
     * @var array<string, LocalizedType>
     */
    protected static $instances;

    /**
     * @param mixed $determinedType
     *
     * @return mixed
     */
    public static function getInstance($determinedType)
    {
        try {
            $determinedTypeName = $determinedType->toString();

            if ($determinedType instanceof ListOfType) {
                $determinedTypeName = $determinedType->getWrappedType()->toString() . 'List';
            }
        } catch (\Throwable $throwable) {
            return $determinedType;
        }

        if (!isset(self::$instances[$determinedTypeName])) {
            $config = ['name' => 'Localized' . $determinedTypeName];

            foreach (Tool::getValidLanguages() as $language) {
                $config['fields'][$language] = [
                    'type' => $determinedType,
                ];
            }

            self::$instances[$determinedTypeName] = new static($config);
        }

        return self::$instances[$determinedTypeName];
    }
}
