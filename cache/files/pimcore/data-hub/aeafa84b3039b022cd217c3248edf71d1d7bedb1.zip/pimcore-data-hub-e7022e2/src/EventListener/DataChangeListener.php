<?php

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\DataHubBundle\EventListener;

use Pimcore\Bundle\DataHubBundle\Configuration;
use Pimcore\Bundle\DataHubBundle\WorkspaceHelper;
use Pimcore\Event\AssetEvents;
use Pimcore\Event\DataObjectEvents;
use Pimcore\Event\DocumentEvents;
use Pimcore\Event\Model\AssetEvent;
use Pimcore\Event\Model\DataObjectEvent;
use Pimcore\Event\Model\DocumentEvent;
use Pimcore\Model\Element\ValidationException;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * @internal
 */
final class DataChangeListener implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            DataObjectEvents::POST_UPDATE => 'onObjectUpdate',
            DataObjectEvents::POST_DELETE => 'onObjectDelete',
            DocumentEvents::POST_UPDATE => 'onDocumentUpdate',
            DocumentEvents::POST_DELETE => 'onDocumentDelete',
            AssetEvents::POST_UPDATE => 'onAssetUpdate',
            AssetEvents::POST_DELETE => 'onAssetDelete',
        ];
    }

    /**
     *
     * @throws ValidationException
     */
    public function onObjectUpdate(DataObjectEvent $e)
    {
        if (!$e->hasArgument('oldPath')) {
            return;
        }

        $object = $e->getObject();
        $oldPath = $e->getArgument('oldPath');

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_OBJECT, WorkspaceHelper::MODIFY_TYPE_REPLACE, $oldPath, $object->getRealFullPath());
    }

    /**
     *
     * @throws ValidationException
     */
    public function onObjectDelete(DataObjectEvent $e)
    {
        $object = $e->getObject();

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_OBJECT, WorkspaceHelper::MODIFY_TYPE_DELETE, $object->getRealFullPath(), null);
    }

    /**
     *
     * @throws ValidationException
     */
    public function onDocumentUpdate(DocumentEvent $e)
    {
        if (!$e->hasArgument('oldPath')) {
            return;
        }

        $document = $e->getDocument();
        $oldPath = $e->getArgument('oldPath');

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_DOCUMENT, WorkspaceHelper::MODIFY_TYPE_REPLACE, $oldPath, $document->getRealFullPath());
    }

    /**
     *
     * @throws ValidationException
     */
    public function onDocumentDelete(DocumentEvent $e)
    {
        $object = $e->getDocument();

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_DOCUMENT, WorkspaceHelper::MODIFY_TYPE_DELETE, $object->getRealFullPath(), null);
    }

    /**
     *
     * @throws ValidationException
     */
    public function onAssetUpdate(AssetEvent $e)
    {
        if (!$e->hasArgument('oldPath')) {
            return;
        }

        $asset = $e->getAsset();
        $oldPath = $e->getArgument('oldPath');

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_ASSET, WorkspaceHelper::MODIFY_TYPE_REPLACE, $oldPath, $asset->getRealFullPath());
    }

    /**
     *
     * @throws ValidationException
     */
    public function onAssetDelete(AssetEvent $e)
    {
        $asset = $e->getAsset();

        $this->checkConfiguration(WorkspaceHelper::MODIFY_SPACE_ASSET, WorkspaceHelper::MODIFY_TYPE_DELETE, $asset->getRealFullPath(), null);
    }

    /**
     * @param string      $dataType
     * @param string      $modificationType
     * @param string      $searchValue
     * @param string|null $replaceValue
     *
     * @throws ValidationException
     */
    protected function checkConfiguration($dataType, $modificationType, $searchValue, $replaceValue)
    {
        $configList = Configuration::getList();

        if (!is_array($configList)) {
            return;
        }

        foreach ($configList as $configurationEntity) {
            try {
                $entity = WorkspaceHelper::modifyWorkspaceRowByType($configurationEntity, $dataType, $modificationType, $searchValue, $replaceValue);
            } catch (\Throwable $e) {
                throw new ValidationException(sprintf('Could not modify workspace row: %s', $e->getMessage()), 0, $e);
            }

            if (!$entity instanceof Configuration) {
                continue;
            }

            try {
                $entity->save();
            } catch (\Throwable $e) {
                throw new ValidationException(sprintf('Could not save configuration: %s', $e->getMessage()), 0, $e);
            }
        }
    }
}
