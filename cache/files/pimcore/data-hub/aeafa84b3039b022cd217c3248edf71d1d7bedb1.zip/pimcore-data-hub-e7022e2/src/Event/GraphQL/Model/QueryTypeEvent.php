<?php

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\DataHubBundle\Event\GraphQL\Model;

use Pimcore\Bundle\DataHubBundle\GraphQL\Query\QueryType;
use Pimcore\Event\Traits\RequestAwareTrait;
use Pimcore\Event\Traits\ResponseAwareTrait;
use Symfony\Contracts\EventDispatcher\Event;

final class QueryTypeEvent extends Event
{
    use RequestAwareTrait;
    use ResponseAwareTrait;

    /**
     * @var QueryType
     */
    protected $queryType;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var array
     */
    protected $context;

    /**
     * @return QueryType
     */
    public function getQueryType()
    {
        return $this->queryType;
    }

    public function setQueryType(QueryType $queryType)
    {
        $this->queryType = $queryType;
    }

    public function getConfig(): array
    {
        return $this->config;
    }

    public function setConfig(array $config): void
    {
        $this->config = $config;
    }

    public function getContext(): array
    {
        return $this->context;
    }

    public function setContext(array $context): void
    {
        $this->context = $context;
    }

    /**
     * @param array $config
     * @param array $context
     */
    public function __construct(QueryType $queryType, $config, $context)
    {
        $this->queryType = $queryType;
        $this->config = $config;
        $this->context = $context;
    }
}
