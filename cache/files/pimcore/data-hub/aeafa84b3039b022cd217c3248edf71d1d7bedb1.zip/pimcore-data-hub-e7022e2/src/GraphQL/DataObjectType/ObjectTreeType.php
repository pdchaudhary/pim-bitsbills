<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\DataHubBundle\GraphQL\DataObjectType;

use GraphQL\Deferred;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\UnionType;
use Pimcore\Bundle\CoreBundle\DependencyInjection\ContainerAwareInterface;
use Pimcore\Bundle\CoreBundle\DependencyInjection\ContainerAwareTrait;
use Pimcore\Bundle\DataHubBundle\Configuration;
use Pimcore\Bundle\DataHubBundle\GraphQL\ClassTypeDefinitions;
use Pimcore\Bundle\DataHubBundle\GraphQL\Service;
use Pimcore\Bundle\DataHubBundle\GraphQL\Traits\ServiceTrait;
use Pimcore\Bundle\DataHubBundle\PimcoreDataHubBundle;
use Pimcore\Cache\RuntimeCache;
use Pimcore\Model\DataObject;

/**
 * @internal
 */
final class ObjectTreeType extends UnionType implements ContainerAwareInterface
{
    use ContainerAwareTrait;
    use ServiceTrait;

    /**
     * @param array $config
     */
    public function __construct(Service $graphQlService, $config = ['name' => 'object_tree'])
    {
        $this->setGraphQLService($graphQlService);
        parent::__construct($config);
    }

    /**
     *
     * @throws \Exception
     */
    public function getTypes(): array
    {
        $context = RuntimeCache::get(PimcoreDataHubBundle::RUNTIME_CONTEXT_KEY);
        /** @var Configuration $configuration */
        $configuration = $context['configuration'];

        $types = array_values(ClassTypeDefinitions::getAll(true));
        if ($configuration->getSpecialEntities()['object_folder']['read'] ?? false) {
            $types[] = $this->getGraphQlService()->getDataObjectTypeDefinition('_object_folder');
        }

        return $types;
    }

    public function resolveType($element, $context, ResolveInfo $info): ObjectType|string|callable|Deferred|null
    {
        if (!$element) {
            return null;
        }
        $object = DataObject\AbstractObject::getById($element['id']);

        if ($object instanceof DataObject\Folder) {
            return $this->getGraphQlService()->getDataObjectTypeDefinition('_object_folder');
        }

        return ClassTypeDefinitions::get($object->getClass());
    }
}
