<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\DataHubBundle\GraphQL\AssetType;

use GraphQL\Deferred;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\UnionType;
use Pimcore\Bundle\CoreBundle\DependencyInjection\ContainerAwareInterface;
use Pimcore\Bundle\CoreBundle\DependencyInjection\ContainerAwareTrait;
use Pimcore\Bundle\DataHubBundle\GraphQL\Service;
use Pimcore\Bundle\DataHubBundle\GraphQL\Traits\ServiceTrait;
use Pimcore\Model\Asset;

/**
 * @internal
 */
final class AssetTreeType extends UnionType implements ContainerAwareInterface
{
    use ContainerAwareTrait;
    use ServiceTrait;

    /**
     * @param array $config
     */
    public function __construct(Service $graphQlService, $config = ['name' => 'asset_tree'])
    {
        $this->setGraphQLService($graphQlService);
        parent::__construct($config);
    }

    /**
     *
     * @throws \Exception
     */
    public function getTypes(): array
    {
        $types = [];
        $types[] = $this->getGraphQlService()->buildAssetType('asset');
        $types[] = $this->getGraphQlService()->getAssetTypeDefinition('_asset_folder');

        return $types;
    }

    public function resolveType($element, $context, ResolveInfo $info): callable|Deferred|ObjectType|null|string
    {
        if (!$element) {
            return null;
        }
        $asset = Asset::getById($element['id']);

        if ($asset instanceof Asset\Folder) {
            return $this->getGraphQlService()->getAssetTypeDefinition('_asset_folder');
        }

        return $this->getGraphQlService()->buildAssetType('asset');
    }
}
