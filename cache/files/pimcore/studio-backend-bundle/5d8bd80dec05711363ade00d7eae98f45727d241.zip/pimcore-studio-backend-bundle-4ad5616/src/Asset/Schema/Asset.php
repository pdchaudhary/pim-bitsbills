<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Schema;

use OpenApi\Attributes\Property;
use OpenApi\Attributes\Schema;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Asset\SearchResult\AssetMetaData;
use Pimcore\Bundle\StudioBackendBundle\Response\Element;
use Pimcore\Bundle\StudioBackendBundle\Response\ElementIcon;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\ElementTypes;
use Pimcore\Bundle\StudioBackendBundle\Util\Schema\AdditionalAttributesInterface;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\AdditionalAttributesTrait;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\CustomAttributesTrait;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\WorkflowAvailableTrait;

#[Schema(
    title: 'Asset',
    required: [
        'hasChildren',
        'type',
        'filename',
        'mimeType',
        'hasMetadata',
        'hasWorkflowWithPermissions',
        'fullPath',
        'customAttributes',
        'permissions',
        'hasWorkflowAvailable',
    ],
    type: 'object'
)]
class Asset extends Element implements AdditionalAttributesInterface
{
    use AdditionalAttributesTrait;
    use CustomAttributesTrait;
    use WorkflowAvailableTrait;

    public function __construct(
        #[Property(description: 'Has children', required: ['hasChildren'], type: 'bool', example: false)]
        private readonly bool $hasChildren,
        #[Property(description: 'Type', type: 'string', example: 'image')]
        private readonly string $type,
        #[Property(description: 'Filename', type: 'string', example: 'cool.jpg')]
        private readonly string $filename,
        #[Property(description: 'Mimetype', type: 'string', example: 'image/jpeg')]
        private readonly ?string $mimeType,
        #[Property(description: 'Has metadata', type: 'bool', example: false)]
        private readonly bool $hasMetadata,
        #[Property(description: 'Workflow permissions', type: 'bool', example: false)]
        private readonly bool $hasWorkflowWithPermissions,
        #[Property(description: 'Full path', type: 'string', example: '/path/to/asset.jpg')]
        private readonly string $fullPath,
        #[Property(ref: AssetPermissions::class)]
        private readonly AssetPermissions $permissions,
        int $id,
        int $parentId,
        string $path,
        ElementIcon $icon,
        int $userOwner,
        ?int $userModification,
        ?string $locked,
        bool $isLocked,
        ?int $creationDate,
        ?int $modificationDate,
        private readonly array $metadata = [],
        private readonly int $fileSize = 0,
    ) {
        parent::__construct(
            $id,
            $parentId,
            $path,
            $icon,
            $userOwner,
            $userModification,
            $locked,
            $isLocked,
            $creationDate,
            $modificationDate,
            ElementTypes::TYPE_ASSET,
        );
    }

    public function getHasChildren(): bool
    {
        return $this->hasChildren;
    }

    public function getHasWorkflowWithPermissions(): bool
    {
        return $this->hasWorkflowWithPermissions;
    }

    public function getFilename(): ?string
    {
        return $this->filename;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getMimeType(): ?string
    {
        return $this->mimeType;
    }

    public function getHasMetadata(): bool
    {
        return $this->hasMetadata;
    }

    public function getFullPath(): string
    {
        return $this->fullPath;
    }

    public function getPermissions(): AssetPermissions
    {
        return $this->permissions;
    }

    /**
     * @return AssetMetaData[]
     */
    public function getMetadata(): array
    {
        return $this->metadata;
    }

    public function getFileSize(): int
    {
        return $this->fileSize;
    }
}
