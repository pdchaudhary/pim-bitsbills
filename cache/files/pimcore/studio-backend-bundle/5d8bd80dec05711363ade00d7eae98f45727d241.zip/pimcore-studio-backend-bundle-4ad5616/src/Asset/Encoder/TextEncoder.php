<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Encoder;

use ForceUTF8\Encoding;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidElementTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\MaxFileSizeExceededException;
use Pimcore\Model\Asset\Text;
use Pimcore\Model\Element\ElementInterface;
use function sprintf;

final class TextEncoder implements TextEncoderInterface
{
    private const MAX_FILE_SIZE = 2000000;

    /**
     * @throws InvalidElementTypeException|MaxFileSizeExceededException
     */
    public function encodeUTF8(ElementInterface $element): string
    {
        if (!$element instanceof Text) {
            throw new InvalidElementTypeException(
                sprintf(
                    'should have been (%s) but was (%s)',
                    Text::class,
                    $element->getType(),
                ),
                'Asset'
            );
        }

        if ($element->getFileSize() > self::MAX_FILE_SIZE) {
            throw new MaxFileSizeExceededException(self::MAX_FILE_SIZE);
        }

        return Encoding::toUTF8($element->getData());
    }
}
